![Screenshot](https://res.cloudinary.com/turnup/image/upload/v1526512881/homepage-cards.png)

# First Node Website Tutorial Starter Files

These are the starter files to accompany the tutorial for building a simple Node.js website with Express and Pug.

You can [access the tutorial here](https://freshman.tech/learn-node).

[Live demo](https://freshman-node.herokuapp.com/)

## Instructions
1. Clone repo
2. Run `npm install`

## Getting Help

Need some help? Leave a comment on the tutorial — this repo is meant as a place to grab the starter files and isn't a support channel.


