from django.apps import AppConfig


class ContactlistbackupConfig(AppConfig):
    name = 'ContactListBackup'
