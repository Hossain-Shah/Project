package com.example.customdatasetrestapidatafetch.remote;

public class ApiUtils {

    private ApiUtils(){
    };

    public static final String API_URL = "http://169.254.35.189:8080/demo/";

    public static UserService getUserService(){
        return RetrofitClient.getClient(API_URL).create(UserService.class);
    }

}
