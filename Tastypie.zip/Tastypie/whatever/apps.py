from django.apps import AppConfig


class WhateverConfig(AppConfig):
    name = 'whatever'
