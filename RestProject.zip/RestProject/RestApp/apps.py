from django.apps import AppConfig


class RestappConfig(AppConfig):
    name = 'RestApp'
