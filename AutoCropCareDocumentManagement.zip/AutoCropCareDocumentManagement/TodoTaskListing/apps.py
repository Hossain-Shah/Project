from django.apps import AppConfig


class TodotasklistingConfig(AppConfig):
    name = 'TodoTaskListing'
