from django.contrib import admin

from MailSite.models import Message
admin.site.register(Message)