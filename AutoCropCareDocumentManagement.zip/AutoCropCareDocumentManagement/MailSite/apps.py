from django.apps import AppConfig


class MailsiteConfig(AppConfig):
    name = 'MailSite'
