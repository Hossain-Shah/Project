from django.contrib import admin
from chat.models import Message
admin.site.register(Message)