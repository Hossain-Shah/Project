from django.contrib import admin
from .models import Diagnosis, TODOItem
admin.site.register(Diagnosis)
admin.site.register(TODOItem)
