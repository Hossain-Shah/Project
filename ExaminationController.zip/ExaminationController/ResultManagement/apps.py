from django.apps import AppConfig


class ResultmanagementConfig(AppConfig):
    name = 'ResultManagement'
