from django.apps import AppConfig


class TodolistConfig(AppConfig):
    name = 'todolist'
