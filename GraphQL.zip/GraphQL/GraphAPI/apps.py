from django.apps import AppConfig


class GraphapiConfig(AppConfig):
    name = 'GraphAPI'
